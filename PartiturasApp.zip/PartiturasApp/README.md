# Partituras (protótipo)

Leitor de partituras em PDF para Android (Kotlin + Jetpack Compose).

## Como abrir
1. Android Studio (Koala ou mais recente) > File > Open > pasta `PartiturasApp`.
2. Esperar pelo Gradle Sync e carregar em Run (telemóvel ou tablet, Android 8+).

## O que já faz
- Importar vários PDFs (copiados para o armazenamento da app).
- Biblioteca com lista alfabética.
- Leitor: toque nas margens vira a página, toque ao centro esconde a barra.
- Duas páginas lado a lado em tablet na horizontal.
- Modo noite (inverte as cores).
- Anotações com caneta/dedo, guardadas por página (`<ficheiro>.pdf.ann.json`).

## Próximos passos
Zoom e deslocamento, borracha, setlists, metrónomo, pedal Bluetooth (teclas Page Up/Down), sincronização com a Google Drive.
