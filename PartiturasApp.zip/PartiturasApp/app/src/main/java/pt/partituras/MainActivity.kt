package pt.partituras

import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

private fun scoresDir(ctx: android.content.Context) =
    File(ctx.filesDir, "scores").apply { mkdirs() }

private fun listScores(ctx: android.content.Context): List<File> =
    scoresDir(ctx).listFiles { f -> f.extension.equals("pdf", true) }
        ?.sortedBy { it.name.lowercase() } ?: emptyList()

private fun importPdf(ctx: android.content.Context, uri: Uri) {
    val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    } ?: "partitura_${System.currentTimeMillis()}.pdf"
    val dest = File(scoresDir(ctx), name)
    ctx.contentResolver.openInputStream(uri)?.use { input ->
        dest.outputStream().use { input.copyTo(it) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    var scores by remember { mutableStateOf(listScores(ctx)) }
    var open by remember { mutableStateOf<File?>(null) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        uris.forEach { importPdf(ctx, it) }
        scores = listScores(ctx)
    }

    BackHandler(enabled = open != null) { open = null }

    val current = open
    if (current != null) {
        ReaderScreen(current) { open = null }
        return
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Biblioteca") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { picker.launch(arrayOf("application/pdf")) }) {
                Text("Importar PDF")
            }
        }
    ) { pad ->
        if (scores.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("Importe a sua primeira partitura")
            }
        } else {
            LazyColumn(Modifier.padding(pad)) {
                items(scores) { f ->
                    ListItem(
                        headlineContent = { Text(f.nameWithoutExtension) },
                        modifier = Modifier.clickable { open = f }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}
