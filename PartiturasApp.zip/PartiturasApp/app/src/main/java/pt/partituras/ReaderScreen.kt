package pt.partituras

import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

private val InvertMatrix = ColorMatrix(
    floatArrayOf(
        -1f, 0f, 0f, 0f, 255f,
        0f, -1f, 0f, 0f, 255f,
        0f, 0f, -1f, 0f, 255f,
        0f, 0f, 0f, 1f, 0f
    )
)

@Composable
fun ReaderScreen(file: File, onBack: () -> Unit) {
    val renderer = remember(file) {
        PdfRenderer(ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY))
    }
    DisposableEffect(renderer) { onDispose { renderer.close() } }
    val lock = remember(renderer) { Mutex() }
    val store = remember(file) { AnnotationStore(File(file.path + ".ann.json")) }

    val cfg = LocalConfiguration.current
    val twoPages = cfg.screenWidthDp >= 600 && cfg.orientation == Configuration.ORIENTATION_LANDSCAPE
    val step = if (twoPages) 2 else 1
    val total = renderer.pageCount

    var page by rememberSaveable(file.name) { mutableIntStateOf(0) }
    var night by rememberSaveable { mutableStateOf(false) }
    var pen by remember { mutableStateOf(false) }
    var showBar by remember { mutableStateOf(true) }

    fun go(delta: Int) { page = (page + delta).coerceIn(0, (total - 1).coerceAtLeast(0)) }

    Column(
        Modifier.fillMaxSize().background(if (night) Color.Black else Color(0xFFF1EFE8))
    ) {
        if (showBar) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TextButton(onClick = onBack) { Text("Voltar") }
                Text(
                    "${page + 1}/$total",
                    color = if (night) Color.White else Color.Black,
                    modifier = Modifier.weight(1f)
                )
                FilterChip(selected = pen, onClick = { pen = !pen }, label = { Text("Caneta") })
                FilterChip(selected = night, onClick = { night = !night }, label = { Text("Noite") })
            }
        }

        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pointerInput(pen, step, total) {
                    if (!pen) detectTapGestures { o ->
                        val w = size.width
                        when {
                            o.x < w * 0.3f -> go(-step)
                            o.x > w * 0.7f -> go(step)
                            else -> showBar = !showBar
                        }
                    }
                }
        ) {
            val density = androidx.compose.ui.platform.LocalDensity.current
            val widthPx = with(density) { (maxWidth / step).roundToPx() }
            Row(Modifier.fillMaxSize()) {
                for (i in 0 until step) {
                    val idx = page + i
                    Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                        if (idx < total) {
                            PageView(renderer, lock, idx, widthPx, night, pen, store)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PageView(
    renderer: PdfRenderer,
    lock: Mutex,
    index: Int,
    widthPx: Int,
    night: Boolean,
    pen: Boolean,
    store: AnnotationStore
) {
    val bitmap by produceState<Bitmap?>(null, renderer, index, widthPx) {
        value = null
        value = withContext(Dispatchers.Default) {
            lock.withLock {
                renderer.openPage(index).use { p ->
                    val scale = widthPx.toFloat() / p.width
                    val bmp = Bitmap.createBitmap(
                        widthPx, (p.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888
                    )
                    bmp.eraseColor(AColor.WHITE)
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp
                }
            }
        }
    }

    val bmp = bitmap ?: return
    val strokes = remember(index) { mutableStateListOf<List<Offset>>().apply { addAll(store.load(index)) } }
    val live = remember(index) { mutableStateListOf<Offset>() }

    Box(Modifier.aspectRatio(bmp.width.toFloat() / bmp.height)) {
        Image(
            bitmap = bmp.asImageBitmap(),
            contentDescription = "Página ${index + 1}",
            modifier = Modifier.fillMaxSize(),
            colorFilter = if (night) ColorFilter.colorMatrix(InvertMatrix) else null
        )
        Canvas(
            Modifier.fillMaxSize().pointerInput(pen, index) {
                if (pen) detectDragGestures(
                    onDragStart = { o -> live.clear(); live.add(norm(o, size.width, size.height)) },
                    onDrag = { change, _ ->
                        change.consume()
                        live.add(norm(change.position, size.width, size.height))
                    },
                    onDragEnd = {
                        if (live.size > 1) {
                            strokes.add(live.toList())
                            store.save(index, strokes)
                        }
                        live.clear()
                    }
                )
            }
        ) {
            val color = if (night) Color(0xFF85B7EB) else Color(0xFF185FA5)
            val width = 3.dp.toPx()
            (strokes + listOf(live.toList())).forEach { s ->
                if (s.size > 1) {
                    val path = Path().apply {
                        moveTo(s[0].x * size.width, s[0].y * size.height)
                        s.drop(1).forEach { lineTo(it.x * size.width, it.y * size.height) }
                    }
                    drawPath(path, color, style = Stroke(width, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
        }
    }
}

private fun norm(o: Offset, w: Int, h: Int) = Offset(o.x / w, o.y / h)
