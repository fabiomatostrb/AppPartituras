package pt.partituras

import androidx.compose.ui.geometry.Offset
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Guarda traços da caneta por página, em coordenadas normalizadas (0..1). */
class AnnotationStore(private val file: File) {
    private val root: JSONObject =
        runCatching { JSONObject(file.readText()) }.getOrDefault(JSONObject())

    fun load(page: Int): List<List<Offset>> {
        val arr = root.optJSONArray(page.toString()) ?: return emptyList()
        return (0 until arr.length()).map { s ->
            val stroke = arr.getJSONArray(s)
            (0 until stroke.length()).map { p ->
                val pt = stroke.getJSONArray(p)
                Offset(pt.getDouble(0).toFloat(), pt.getDouble(1).toFloat())
            }
        }
    }

    fun save(page: Int, strokes: List<List<Offset>>) {
        val arr = JSONArray()
        strokes.forEach { stroke ->
            val s = JSONArray()
            stroke.forEach { s.put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble())) }
            arr.put(s)
        }
        root.put(page.toString(), arr)
        file.writeText(root.toString())
    }
}
